import java.io.Serializable;

public class User implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	// properties that will be used by both the admin and student object
	protected String username;
	protected String password;
	protected String firstName;
	protected String lastName;
	
	// methods that will be implemented in both admin and student class
	
	public void setUsername(String userName) {
		this.username = userName;
		
	}
	
	public String getUsername() {
		return this.username;
		
	}
	

	public void setPassword(String passWord) {
		this.password = passWord;
		
	}
	
	public String getPassword() {
		return this.password;
		
		
	}
	
	public void setFirstName(String name) {
		this.firstName = name;
		
	}
	
	public String getFirstName() {
		return this.firstName;
		
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
		
	}
	
	public String getLastName() {
		return this.lastName;
		
	}
	
	

}

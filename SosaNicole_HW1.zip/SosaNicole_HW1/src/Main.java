
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.io.*;


public class Main {
		
		public static void main(String[] args) throws NumberFormatException, IOException {
			
			ArrayList <Course> course_List = new ArrayList <Course>();
			
			Admin admin = new Admin("Admin", "Admin001");
			
			// check if the serialized file exists 
			File checkFile = new File("MyUniversityCourses.ser");
			
			// the file exists condition
			if (checkFile.exists() == false)
			{
				// read the csv file 
				String fileName  = "MyUniversityCourses.csv";
				String line = null;
				
				try {
					FileReader fileReader = new FileReader(fileName);
					BufferedReader bufferedReader = new BufferedReader(fileReader);
					bufferedReader.close();
				}
				
				// this will catch any errors that occur when reading the file
				catch (FileNotFoundException e) {
					e.printStackTrace();
				} 
				catch (IOException e) {
					e.printStackTrace();
				}
				
				// parse through the csv file and store all the course data into a course array list 
				try {
					// change the file into a string 
					String input = new Scanner(new File(fileName)).useDelimiter("\\A").next();
			
					// removes the first line with all the headings
					input=input.replace("Course_Name,", "")
							.replace("Course_Id,", "").replace("Maximum_Students,", "")
							.replace("Current_Students,", "").replace("List_Of_Names,", "").replace("Course_Instructor,", "")
							.replace("Course_Section_Number,", "").replace("Course_Location", "").replace("NULL,","");
					
					// eliminates the extra line created 
					String line2 = input.trim();
					
					// the tokenizer will seperate all the data by commas and extra line
					StringTokenizer strTokens = new StringTokenizer(line2,",\n");
					
					// this loop will continue to parse until there is no more data left 
					while (strTokens.hasMoreTokens()){
						
						// this stored data will be used to instantiate a course 
						String Course_Name =  strTokens.nextToken();
						String Course_ID =  strTokens.nextToken();
						int Maximum_Students = Integer.parseInt(strTokens.nextToken());
						int Current_Students = Integer.parseInt(strTokens.nextToken());
						String Course_Instructor = strTokens.nextToken();
						String Course_Section_Number = strTokens.nextToken();
						String Course_Location = strTokens.nextToken();
						
						//creates a course object from the elements found
						Course course__Object = new Course(Course_Name, Course_ID, Maximum_Students, Current_Students, 
								Course_Instructor, Course_Section_Number, Course_Location);
					
						// adds each course object to the course list array list
						course_List.add(course__Object);
						
					}
				}
			
				catch (FileNotFoundException e) {
					e.printStackTrace();
				} 
				
				catch (IOException e) {
					e.printStackTrace();
				}
				
			
			}
			
			// Deserialize the course list data 
			else {
				course_List = deserializeCourseList(course_List);
			}
			
			// if the admin registered ser file exists, deserialize it 
			File checkFile2 = new File("AdminRegisteredStudents.ser");
			if (checkFile2.exists() == true) {
				admin.registeredStudents = deserializeAdminRegisteredStudents(admin.registeredStudents);
			}
			
			// Login and Menu section of the program
			BufferedReader br = new BufferedReader (new InputStreamReader(System.in)); 
			
			// welcome statement
			System.out.println("Welcome to the Course Registration Tool!");
			
			// ask the user for their choice of user
			System.out.println("\nPlease choose your user type:\n \n(1)Admin \n(2)Student");
			System.out.print("\nEnter your choice: ");
			int choice = Integer.parseInt(br.readLine());
			
			// Admin User
			if (choice == 1) {
				
				// Now ask Admin to input their username and password
				System.out.println("\nAdmin Login");
				System.out.print("\nEnter your username: ");
				String username = br.readLine();
				System.out.print("Enter your password: ");
				String password = br.readLine();
				
				// ask admin to chose which menu either course management or report menu 
				admin.displayAdminMenuChoices();
				int menuChoice = Integer.parseInt(br.readLine());
				
				while (true) {
					
					// course Management condition
					if (menuChoice == 1) {
						
						//display the course management menu
						admin.displayAdminCourseMenu();
						int manageChoice = Integer.parseInt(br.readLine());
					
						// Condition: Admin wants to create a new course
						if (manageChoice == 1) {
							admin.createCourse(course_List);	
						}
						
						// Condition: Admin wants to delete a course
						else if(manageChoice == 2) {
							admin.deleteCourse(course_List);
						}
											
						// Condition: Admin wants to edit a course
						else if(manageChoice == 3) {
							// only need to edit location
							admin.editCourse(course_List);
						}
											
						// Condition: Admin wants to display information for a given course
						else if(manageChoice == 4) {
							admin.displayCourseSectionInfo(course_List);	
						}
											
						// Conidtion: Admin wants to register a student without assigning them to a course
						else if(manageChoice == 5) {
							admin.registerStudent();	
						}
											
						// Conidtion: Admin wants to leave this program
						else if (manageChoice == 6){
							System.out.println("\nYou have been logged out. Goodbye!");
							serializeCourseList(course_List);
							serializeAdminRegisteredStudents(admin.registeredStudents);
							System.exit(0);
						}
						// After each choice, ask admin if they want to end the program or continue 
						System.out.print("\n\nDo you want to do anything else (type anything = yes or n = no)? " );
						String answer = br.readLine();
						if (answer.equals("n")) {
							System.out.println("\nYou have been logged out. Goodbye!");
							serializeCourseList(course_List);
							serializeAdminRegisteredStudents(admin.registeredStudents);
							System.exit(0);
							
						}
						
					}
				
								
					// Condition: Admin's Report Menu 
					else if (menuChoice == 2) {
						admin.displayAdminReportMenu();	
						
						int manageChoice = Integer.parseInt(br.readLine());
						
						// Condition: Admin wants to view all courses
						if (manageChoice == 1) {
							admin.viewAllCourses(course_List);	
						}
						
						// Condition: Admin wants to view all courses that are full
						else if(manageChoice == 2) {
							admin.viewFullCourses(course_List);	
						}
											
						// Condition: Admin wants to write to a file the list of courses that are full
						else if(manageChoice == 3) {
							// only need to edit location
							admin.writeFullCoursesFile(course_List);
						}
											
						// Condition: Admin wants to view the names of the students being registered in a specific course
						else if(manageChoice == 4) {
							admin.viewRegisteredStudentNames(course_List);
						}
											
						// Condition: Admin wants to view the list of courses that a given student is being registered on
						else if(manageChoice == 5) {
							admin.displayStudentCourses(course_List);
						}
											
						// Condition: Admin wants to sort the courses based on the current number of student registers
						else if (manageChoice == 6){
							admin.sortCourses(course_List);
						}
						
						// Condition: leave the program
						else if (manageChoice == 7){
							System.out.println("\nYou have been logged out. Goodbye!");
							serializeCourseList(course_List);
							serializeAdminRegisteredStudents(admin.registeredStudents);
							System.exit(0);
						}
						
						// After each choice, ask admin if they want to end the program or continue 
						System.out.print("\n\nDo you want to do anything else (type y = yes or n = no)? " );
						String answer = br.readLine();
						if (answer.equals("n")) {
							System.out.println("\nYou have been logged out. Goodbye!");
							serializeCourseList(course_List);
							serializeAdminRegisteredStudents(admin.registeredStudents);
							System.exit(0);
							
						}
					
					}
				}
					
			}
			
			// Student User 
			else if (choice  == 2) {
				
				System.out.println("\nStudent Login");
				
				// ask student to log in
				System.out.print("\nEnter your username: ");
				String username = br.readLine();
				System.out.print("Enter your password: ");
				String password = br.readLine();
				
				// check if the student exists by validating their username and password
				for (Student s: admin.getRegisteredStudentList()) {
					
					if (s.username.equals(username) && s.password.equals(password)) {
						
						// welcome statement to student user
						System.out.println("\nWelcome " + s.firstName+"!");
						
						// display the student's menu after they have successfully logged in
						while (true) {
						
							System.out.println("\n(1) View all courses");
							System.out.println("\n(2) View all courses that are not full");
							System.out.println("\n(3) Register on a course");
							System.out.println("\n(4) Withdraw from a course");
							System.out.println("\n(5) View all courses that your are registered in");
							System.out.println("\n(6) Exit");
							
							// read the student's choice
							System.out.print("\nEnter your choice: ");
							int studentChoice = Integer.parseInt(br.readLine());
							
							// condition 1: student wants to view all the courses 
							if (studentChoice == 1) {
								s.viewAllCourses(course_List);
							}
							
							// condition 2: student wants to view all the courses that are not full
							else if (studentChoice == 2) {
								s.viewAllNotFullCourses(course_List);	
							}
							
							// condition 3: student wants to register for a course
							else if (studentChoice == 3) {
								s.registerCourse(course_List);
							}
							
							// condition 4: student wants to withdraw from a course
							else if (studentChoice == 4) {
								s.withdrawCourse(course_List);
							}
							
							// condition 5: students wants to view all their registered courses
							else if (studentChoice == 5) {
								s.viewCurrentCourses(course_List);	
							}
							
							// condition 6: student has finished all they needed to do and once to leave the program
							else if (studentChoice == 6 ) {
								System.out.println("\nYou have been logged out. Goodbye!");
								serializeCourseList(course_List);
								serializeAdminRegisteredStudents(admin.registeredStudents);
								System.exit(0);
							}
							
							// After each choice, ask student if they want to end the program or continue 
							System.out.print("\n\nDo you want to do anything else (type y = yes or n = no)? " );
							String answer = br.readLine();
							if (answer.equals("n")) {
								System.out.println("\nYou have been logged out. Goodbye!");
								serializeCourseList(course_List);
								serializeAdminRegisteredStudents(admin.registeredStudents);
								System.exit(0);
								
							}
						}
						
					}
					
					
				}
				
				
			}
			
			
		}		
		
		// method used to deserialize the course list data
		public static ArrayList <Course> deserializeCourseList(ArrayList <Course> course_List) {
			
			try {
				// retrieve the ser file
				FileInputStream fis = new FileInputStream("MyUniversityCourses.ser");
				
				// changes the bystream data back into object data type
				ObjectInputStream ois = new ObjectInputStream(fis);
				
				// store the saved data (deserialized data) back into the course list used in this program
				course_List = (ArrayList<Course>)ois.readObject();
				ois.close();
				fis.close();
				
			} 
			
			catch (IOException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			// return this course list arrayList back into the main program
			return course_List;
			
		}
		
		//method used to serialize the course list data
		public static void serializeCourseList(ArrayList <Course> course_List) {
			
			try {
				FileOutputStream fos = new FileOutputStream("MyUniversityCourses.ser");
				ObjectOutputStream oos = new ObjectOutputStream(fos);
				
				//Writes the specific object to the OOS
				oos.writeObject(course_List);
				
				//Close both streams
				oos.close();
				fos.close();
				
			} 
			catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		// method used to deserialize the admin registered student list data 
		public static ArrayList <Student> deserializeAdminRegisteredStudents(ArrayList <Student> registeredStudents) {
			try {
				// obtaining the byte files (serialized file)
				FileInputStream fis = new FileInputStream("AdminRegisteredStudents.ser");
				
				// changes the bysteam back into object data type
				ObjectInputStream ois = new ObjectInputStream(fis);
		
				// the deserialized data is stored in the course list 
				registeredStudents = (ArrayList<Student>)ois.readObject();
				ois.close();
				fis.close();
				
			} 
			
			catch (IOException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// return the saved data back into the main program
			return registeredStudents;
			
		}
		
		// method used to serialize the admin registered student list data 
		public static void serializeAdminRegisteredStudents(ArrayList <Student> registeredStudents) {
			
			try {
				FileOutputStream fos = new FileOutputStream("AdminRegisteredStudents.ser");
				ObjectOutputStream oos = new ObjectOutputStream(fos);
				
				// Writes the specific object to ser file 
				oos.writeObject(registeredStudents);
				
				//Close both streams
				oos.close();
				fos.close();
				
			} 
			catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
}
		
		
		
		

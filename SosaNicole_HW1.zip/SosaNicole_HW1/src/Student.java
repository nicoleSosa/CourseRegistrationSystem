import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;

public class Student extends User implements StudentInterface,Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	// keep track of all the courses, the student is enrolled in
	private ArrayList <Course>studentCourseList;
	
	// constructor for Student
	public Student(String user_Name, String password, String first_Name, String last_Name) {
		this.username = user_Name;
		this.password = password;
		this.firstName = first_Name;
		this.lastName = last_Name;
		this.studentCourseList = new ArrayList <Course> ();
		
	}
	
	// allow the student to get the student course list (all their registered courses)
	public ArrayList <Course> getStudentCourseList(){
		return this.studentCourseList;
	}


	// allow the student to view all the courses offered in the school system
	@Override
	public void viewAllCourses(ArrayList<Course> course_List){
		
		System.out.println("\nView All Courses:\n ");
		
		// show the course name, course id, # of students registered, maximum number of students allowed to register
		System.out.printf("%42s %44s %53s %54s", "COURSE NAME", "COURSE ID", "# OF REGISTERED STUDENTS", "MAXIMUM REGISTERED STUDENTS");  
		for (Course c: course_List) {
			System.out.printf("\n%42s %45s %50d %55d", c.getCourseName(), c.getCourseID(),c.getCurrentStudentsNum(),c.getMaxStudentsNum());
			
		}
		
	}
		
	// allow the student to view all available courses
	@Override
	public void viewAllNotFullCourses(ArrayList<Course> course_List) {
		
		System.out.println("\nAll Unfilled Course:\n ");
		
		System.out.printf("%42s %44s %53s %54s", "COURSE NAME", "COURSE ID", "# OF REGISTERED STUDENTS", "MAXIMUM REGISTERED STUDENTS");  
		for (Course c: course_List) {
			// this is course is not full if the current number of students is always less than the maximum number of students 
			if (c.getCurrentStudentsNum() < c.getMaxStudentsNum()) {
				System.out.printf("\n%42s %45s %50d %55d", c.getCourseName(), c.getCourseID(),c.getCurrentStudentsNum(),c.getMaxStudentsNum());
			}
		}	
		
	}
	
	// allows student to register for a course
	@Override
	public void registerCourse(ArrayList<Course> course_List) {
		
		BufferedReader br = new BufferedReader (new InputStreamReader(System.in));;
		String courseID;
		String courseSection;
		
		try {
			
			System.out.print("\nWhat is the course ID for the course you want to register in? ");
			courseID = br.readLine();
			System.out.print("What is the course section for the course you want to register in? ");
			courseSection = br.readLine();
			
			

			// iterate through course_List and find that specific course 
			
			for (Course c: course_List) {
				// for each of the courses, get the course name and section number and match it 
				if( c.getCourseID().equals(courseID) && c.getCourseSectionNum().equals(courseSection)) {
					
					// only add a student if the course reigster number < max number 
					
					if (c.getCurrentStudentsNum() < c.getMaxStudentsNum())
					{
						Student s = new Student (this.username,this.password,this.firstName,this.lastName);
					
						// create a new student to add to this studentList
						c.addStudent(s);
						c.addStudentNames(this.firstName);
						c.addToCurrentStudentsNum();
						
						// add this to student's own course list
						this.studentCourseList.add(c);
						// tell student they have successfully registered for a course
						System.out.print("\nYou have succesfully registered for this course!");
						
						break;
					}
					else {
						System.out.print("\nSorry, this class is full. You can't enroll in it.");
						break;
					}
	
				}
				
			}
			
			
			
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	
	}
	
	// allow the student to withdraw from a course
	@Override
	public void withdrawCourse(ArrayList<Course> course_List) {
		
		BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
		String courseID;
		String courseSection;
		
		try {
			
			System.out.print("\nWhat is the course ID for the course you want to delete? ");
			courseID = br.readLine();
			System.out.print("What is the course section for the course you want to delete? ");
			courseSection = br.readLine();
			
			//  remove this class from the studentCourseList 
			for (Course c: this.studentCourseList) {
				if( c.getCourseID().equals(courseID) && c.getCourseSectionNum().equals(courseSection)) {
					this.studentCourseList.remove(c);
					break;
				}
				
			}
			
			// remove student from the course studentList and from the student name list
			for (Course c: course_List) {
				
				// for each of the courses, get the course name and section number and match it 
				if( c.getCourseID().equals(courseID) && c.getCourseSectionNum().equals(courseSection)) {
					// remove the student from this course student name list
					c.removeStudentNames(this.firstName);
					c.subtractCurrentStudentsNum();
					// iterate through the student list of this course to find this specific student
					for (Student s:c.getStudentList()) {
						if (s.firstName == this.firstName && s.lastName == this.lastName) {
							c.removeStudent(s);
							break;
						}
					}
									
				}
				
			}
			
			System.out.print("\nYou have successfully deleted this course!");
			
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	// display to student all their enrolled courses
	@Override
	public void viewCurrentCourses(ArrayList<Course> course_List) {
		
		if (studentCourseList.size() != 0) {
			System.out.printf("%30s %38s %42s %44s", "COURSE NAME", "COURSE ID", "SECTION NUMBER", "INSTRUCTOR");  
			
			for (Course c: studentCourseList) {
				System.out.printf("\n%32s %36s %37s %38s", c.getCourseName(), c.getCourseID(), c.getCourseSectionNum(), c.getCourseInstructor());
			}	
		}
		else {
			
			System.out.print("\nNo registered courses.");
			
		}
	}	
		
	
}

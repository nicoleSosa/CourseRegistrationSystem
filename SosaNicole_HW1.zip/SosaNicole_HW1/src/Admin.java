import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;


public class Admin extends User implements AdminInterface {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	BufferedReader br ;
	
	// arrayList will allow admin to keep track of all the student they have registered
	static ArrayList <Student> registeredStudents = new ArrayList <Student>();
	
	// constructor 
	public Admin(String userName, String passWord ){
		this.br = new BufferedReader (new InputStreamReader(System.in));
		this.username = userName;
		this.password = passWord;
	}
	
	
	// allow admin to create a new course that will be added to the course list
	@Override
	public void createCourse( ArrayList<Course> course_List) {
		
		// ask admin for all the information needed to instantiate a new course object
		try {
			
			System.out.println("\nCreate a Course: ");
			System.out.print("\nEnter the name of the course: ");
			String courseName = br.readLine();
			System.out.print("Enter the Course ID: ");
			String courseID = br.readLine();
			System.out.print("Enter the maximum number of Students for the class: ");
			int maxStudents = Integer.parseInt(br.readLine());
			System.out.print("Enter the current number of students in this class: ");
			int currentStudents = Integer.parseInt(br.readLine());
			System.out.print("Enter the course instructor for the class: ");
			String courseInstructor = br.readLine();
			System.out.print("Enter the course section number: ");
			String courseSection = br.readLine();
			System.out.print("Enter the course location: ");
			String courseLocation = br.readLine();
			
			// create a course object and add it to the course_List ArrayList
			Course newCourse = new Course(courseName, courseID, maxStudents, currentStudents, courseInstructor, courseSection, courseLocation);
			course_List.add(newCourse);
			System.out.print("\nYou have successfully added the course! ");
			
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	
	}
	
	// allow admin to delete any course from the course list
	@Override
	public void deleteCourse( ArrayList<Course> course_List) {
		try {
			
			System.out.println("\nDelete a Course: ");
			System.out.print("\nWhat is the Course ID of the course you want to delete? ");
			String courseID = br.readLine();
			System.out.print("What is the course section number of this course?");
			String courseSection = br.readLine();
			
			// iteriate through the course list and find the course and edit the location using index
			int index = 0;
			for (Course c: course_List) {
				// for each of the courses, get the course name and section number and match it 
				if( c.getCourseID().equals(courseID) && c.getCourseSectionNum().equals(courseSection)) {
					break;	
				}
				index++;
			}
			
			
			course_List.remove(index);
			// inform user that their action was successfull
			System.out.print("\nThe course has been successfully removed!");
					
		} 
		
		catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	// only need to edit location 
	@Override
	public void editCourse( ArrayList<Course> course_List) {
		
		// to change a course, we need the name and the section of the course from admin
		try {
			
			// ask admin for the information
			System.out.println("Edit A Course: ");
			System.out.print("\nWhat is the Course ID of the course you want to edit?");
			String courseID = br.readLine();
			System.out.print("What is the course section number of this course?");
			String courseSection = br.readLine();
			
			// iteriate through the course list and find the course and edit the location using index
			int index = 0;
			for (Course c: course_List) {
				
				// for each of the courses, get the course name and section number and match it 
				if( c.getCourseID().equals(courseID) && c.getCourseSectionNum().equals(courseSection)) {
					System.out.print("What is the new location for this course? ");
					String courseLocation = br.readLine();
					course_List.get(index).setCourseLocation(courseLocation);
					System.out.print("\nThe change has been successfully made!");			
				}
				
				index++;
				
			}
					
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	@Override
	public void displayCourseSectionInfo(ArrayList<Course> course_List) {
		
		try {
			// ask admin for the course id and section number of the course, they want to display information for
			System.out.println("\nCourse Information: ");
			System.out.print("\nWhat is the Course ID of the course you want to display? ");
			String courseID = br.readLine();
			System.out.print("What is the course section number of this course? ");
			String courseSection = br.readLine();
			
			
			int index = 0;
			for (Course c: course_List) {
				// for each of the courses, get the course name and section number and match it 
				if( c.getCourseID().equals(courseID) && c.getCourseSectionNum().equals(courseSection)) {
					break;		
				}
				index++;
			}
			
			// display the information for this course in a formatted table like structure
			System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
			System.out.println("Course Name:"+course_List.get(index).getCourseName());
			System.out.println("Course ID: "+course_List.get(index).getCourseID());
			System.out.println("Maximum Students: "+course_List.get(index).getMaxStudentsNum());
			System.out.println("Current Students: "+ course_List.get(index).getCurrentStudentsNum());
			System.out.println("Course Instructor: "+course_List.get(index).getCourseInstructor());
			System.out.println("Course Section: "+ course_List.get(index).getCourseSectionNum());
			System.out.print("Course Location: "+ course_List.get(index).getCourseLocation());
			
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	// allow admin to register a student without adding them to a course
	@Override
	public void registerStudent() {
		
		try {
			// ask admin for the student name, last name, username, and password 
			System.out.println("\nRegister a Student: ");
			System.out.print("\nWhat is the name of the student? ");
			String name;
			name = br.readLine();
			System.out.print("What is the last name of the student? ");
			String lastName = br.readLine();
			System.out.print("What is the username for the student? ");
			String userName = br.readLine();
			System.out.print("What is the password for the student? ");
			String password = br.readLine();
			
			// add a new student to the registered student list 
			Student s = new Student(userName,password,name,lastName);
			registeredStudents.add(s);
			
			// reassure Admin that they have successfully added a student
			System.out.print("\nYou have succesfully registered " +name+ " as a student!");
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
			
	}
	
	// allow you to obtain all the students the admin registered
	public ArrayList <Student> getRegisteredStudentList() {
			return registeredStudents;
	}
	
	// allow admin to view all the courses currently in the course list in a formatted table like structure
	@Override
	public void viewAllCourses(ArrayList<Course> course_List) {
		
		System.out.println("\nAll Courses:\n ");
		
		// display the course name, course id, # of students registered, maximum number of students allowed to register
		System.out.printf("%42s %44s %53s %54s", "COURSE NAME", "COURSE ID", "# OF REGISTERED STUDENTS", "MAXIMUM REGISTERED STUDENTS");  
		for (Course c: course_List) {
			System.out.printf("\n%42s %45s %50d %55d", c.getCourseName(), c.getCourseID(),c.getCurrentStudentsNum(),c.getMaxStudentsNum());
			
		}
		
	}
	
	// display only information about the full courses 
	@Override
	public void viewFullCourses(ArrayList<Course> course_List) {
		
		System.out.println("\nAll Full Courses: \n");
		System.out.printf("%42s %44s %53s %54s", "COURSE NAME", "COURSE ID", "# OF REGISTERED STUDENTS", "MAXIMUM REGISTERED STUDENTS");  
		for (Course c: course_List) {
			// check if the # of registered student matches the maximum registered student = full class
			if (c.getCurrentStudentsNum() == c.getMaxStudentsNum()) {
				System.out.printf("\n%42s %45s %50d %55d", c.getCourseName(), c.getCourseID(),c.getCurrentStudentsNum(),c.getMaxStudentsNum());
			}
		}	
		
	}
	
	// allow admin to write only the full courses to a text file
	@Override
	public void writeFullCoursesFile(ArrayList<Course> course_List) {
		
		String fileName = "fullCourses.txt";
		Scanner scan = new Scanner(System.in);
		
		try{
			FileWriter fileWriter = new FileWriter(fileName);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.write("Full Courses:");
			bufferedWriter.newLine();
			for (Course c: course_List) {
				// write only the full courses 
				if (c.getCurrentStudentsNum() == c.getMaxStudentsNum()) {
					String courseName = c.getCourseName();
					bufferedWriter.write(courseName);
					bufferedWriter.newLine();
				}
			}
			System.out.print("\nAll the full courses have been written to a text file! ");;
		
			//close writer
			bufferedWriter.close();
		}

		catch (IOException exk) {
			System.out.println( "Error writing file '" + fileName + "'");
			exk.printStackTrace();
		}
		
	}
	
	// allow admin to view only the names of the registered students for a class 
	@Override
	public void viewRegisteredStudentNames(ArrayList<Course> course_List) {
		
		try {
			
			System.out.print("\nWhat is the Course ID of the course? ");
			String courseID = br.readLine();
			System.out.print("What is the course section number for this course? ");
			String courseSection = br.readLine();
			System.out.print("\nStudent Names In This Course:\n ");
			//now try to find this course 
			int index = 0;
			for (Course c: course_List) {
				
				// for each of the courses, get the course name and section number and match it 
				if( c.getCourseID().equals(courseID) && c.getCourseSectionNum().equals(courseSection)) {
					
					// iterate through the list and print out each name on its own line
					if (c.getStudentNames().size()!= 0) {
						for (String name: c.getStudentNames()) {
							System.out.println(name);
						}
		
						break;
					}
					else {
						System.out.print("\nCurrently, no students enrolled in this class.");
					}
				}
				index++;
			}
			
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	// allow admin to view all of the courses a student is enrolled in
	@Override
	public void displayStudentCourses(ArrayList<Course> course_List) {
		try {
			// ask admin for the student first and last name to find the student they want 
			System.out.print("\nWhat is the name of the student? ");
			String studentName = br.readLine();
			System.out.print("What is the last name of the student? ");
			String studentLastName = br.readLine();
			System.out.println("\nStudent's Courses:\n ");
			
			// now find the student in registered student names list and invoke their schedule method to obtain all their courses
			for (Student s:registeredStudents) {
				if (s.firstName.equals(studentName) && s.lastName.equals(studentLastName)){
					if (s.getStudentCourseList().size()!= 0) {
						// now print out each course the student is enrolled in
						System.out.printf("%42s %49s %53s %53s", "COURSE NAME", "COURSE ID", "# OF REGISTERED STUDENTS", "MAXIMUM REGISTERED STUDENTS");  
						for (Course c: s.getStudentCourseList()) {
							System.out.printf("\n%42s %45s %50d %55d", c.getCourseName(), c.getCourseID(),c.getCurrentStudentsNum(),c.getMaxStudentsNum());
						}
						break;
					}
					else {
						System.out.print("\nNo registered courses.");
					}
				}
			}

		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	// sort courses based on the number of student registers 
	@Override
	public void sortCourses(ArrayList<Course> course_List) {
		
		// n = courses that are not the current course and c = current course
		
		// iterate through the entire courseList 
		for (int c = 0; c < course_List.size(); c++) {
			
			//descend from the last course, this will compare the first course with each of the courses
			// starting from the last course until it reaches the course being compared to
			for (int n = course_List.size() - 1; n > c; n--) {
				
				// condition that course at index b is greater than all the other courses current student registers
				if (course_List.get(c).getCurrentStudentsNum() > course_List.get(n).getCurrentStudentsNum()) {
					
					Course new_Location = course_List.get(c);
					
					// swap the course location for a and b b/c b has a greater current students number
					course_List.set(c, course_List.get(n));
					course_List.set(n, new_Location);
					
				}

			}

		}
		
		//display the new courseList for admin
		viewAllCourses(course_List);
		
		// display this message to user to ensure that their task has been completed
		System.out.println("\nSort has been completed!");

	}
	
	// this menu will ask which of the two menu admin wants 
	public void displayAdminMenuChoices(){
		System.out.println("\nDo you want the Admin's Course Management Menu or the Report Menu? ");
		System.out.println("\n(1) Admin's Course Management Menu ");
		System.out.println("\n(2) Admin's Report Menu ");
		System.out.print("\nEnter your choice:  ");
	}
	
	
	// this menu will display to admin all of their options in the course management menu
	public void displayAdminCourseMenu(){
		System.out.println("\nAdmin's Course Management Menu");
		System.out.println("\n(1) Create a new course");
		System.out.println("\n(2) Delete a course");
		System.out.println("\n(3) Edit a course");
		System.out.println("\n(4) Display information for a given course");
		System.out.println("\n(5) Register a student");
		System.out.println("\n(6) Exit");
		System.out.print("\nEnter your choice:  ");
		
	}
	
	// this menu will display to admin all of their options in the report menu
	public void displayAdminReportMenu() {
		System.out.println("\nAdmin's Report Menu");
		System.out.println("\n(1) View all courses");
		System.out.println("\n(2) View all courses that are full");
		System.out.println("\n(3) Write to a file the list of courses that are full");
		System.out.println("\n(4) View the names of the students being registered in a specific course");
		System.out.println("\n(5) View the list of courses that a given student is being registered on");
		System.out.println("\n(6) Sort courses based on the current number of student registers");
		System.out.println("\n(7) Exit");
		System.out.print("\nEnter your choice:  ");
	}
	
}

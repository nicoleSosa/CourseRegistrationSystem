import java.util.ArrayList;
import java.io.*;

public class Course implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	// properties of a course 
	private String courseName; 
	private String courseID;
	private int maxStudentsNum;
	private int currentStudentsNum;
	private String courseInstructor;
	private String courseSectionNum;
	private String courseLocation;
	
	//arrayList will allow us to to retrieve just the names of the students registered in this class
	private ArrayList <String> studentNames;
	
	// store all the students registered in this class
	private ArrayList <Student> studentList;
	
	// constructor for Course class
	public Course(String Course_Name, String Course_ID, int Maximum_Students, int Current_Students,
			String Course_Instructor, String Course_Section_Number, String Course_Location){
		this.courseName = Course_Name;
		this.courseID = Course_ID;
		this.maxStudentsNum = Maximum_Students;
		this.currentStudentsNum = Current_Students;
		this.courseInstructor =  Course_Instructor;
		this.courseSectionNum = Course_Section_Number;
		this.courseLocation = Course_Location;	
		// get their names 
		this.studentNames = new ArrayList <String> ();
		// keep track of all the student objects and their personal information
		this.studentList = new ArrayList <Student>();
	}
	
	
	//add to studentList
	public void addStudent(Student s) {
		this.studentList.add(s);
	}
	
	// remove a student from studentlist
	public void removeStudent(Student s) {
		this.studentList.remove(s);
	}
	
	// get the studentList
	public ArrayList <Student> getStudentList(){
		return this.studentList;
	}
	
	// returns the course name
	public String getCourseName() {
		return this.courseName;
	}

	// returns the course ID
	public String getCourseID() {
		return this.courseID;
		
	}
	
	// returns the maximum number of students for this course
	public int getMaxStudentsNum() {
		return this.maxStudentsNum;
		
	}
	
	// returns the current number of students enrolled for this course
	public int getCurrentStudentsNum() {
		return this.currentStudentsNum;
		
	}
	
	// returns the course instructor for this course
	public String getCourseInstructor() {
		return this.courseInstructor;
		
	}
	
	// returns the course section number
	public String getCourseSectionNum() {
		return this.courseSectionNum;
		
	}
	
	// returns the location of where this course is taking place
	public String getCourseLocation() {
		return this.courseLocation;
		
	}
	
	// returns the list of student names for this course 
	public ArrayList <String> getStudentNames(){
		return this.studentNames;
	}
	
	// remove the name of a student 
	public void removeStudentNames(String name){
		studentNames.remove(name);
		
	}
	
	// add the name of a student to this list
	public void addStudentNames(String name){
		studentNames.add(name);
	}

	// change the course name
	public void setCourseName(String courseName){
		this.courseName = courseName;
		
	}
	
	// change the course ID
	public void setCourseID(String courseID) {
		this.courseID = courseID;
		
	}
	
	// change the maximum number of students for a course
	public void setMaxStudentsNum(int maxNum) {
		this.maxStudentsNum = maxNum;
	}
	
	// change the current number of students enrolled for a course
	public void setCurrentStudentsNum(int num) {
		this.currentStudentsNum = num;
		
	}
	
	// change the number of current students in a class
	public void addToCurrentStudentsNum() {
		this.currentStudentsNum+=1;
	}
	public void subtractCurrentStudentsNum() {
		this.currentStudentsNum-=1;
	}
	
	
	// change the course instructor
	public void setCourseInstructor(String courseInstructor) {
		this.courseInstructor = courseInstructor;
		
	}
	
	// change the course section number
	public void setCourseSectionNum(String courseSectionNum) {
		this.courseSectionNum = courseSectionNum;
		
	}
	
	// edit the course location 
	public void setCourseLocation(String Course_Location) {
		this.courseLocation = Course_Location;
		
	}
		
}

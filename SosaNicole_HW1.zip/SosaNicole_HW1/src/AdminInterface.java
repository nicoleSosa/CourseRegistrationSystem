import java.util.ArrayList;

public interface AdminInterface {
	
	// all the tasks that an admin should be able to do in the course registration system
	
	public abstract void createCourse(ArrayList<Course> course_List);
	public abstract void deleteCourse(ArrayList<Course> course_List);
	public abstract void editCourse( ArrayList<Course> course_List);
	public abstract void displayCourseSectionInfo(ArrayList<Course> course_List);
	public abstract void registerStudent();
	public abstract void viewAllCourses(ArrayList<Course> course_List);
	public abstract void viewFullCourses(ArrayList<Course> course_List);
	public abstract void writeFullCoursesFile(ArrayList<Course> course_List);
	public abstract void viewRegisteredStudentNames(ArrayList<Course> course_List);
	public abstract void displayStudentCourses(ArrayList<Course> course_List);
	public abstract void sortCourses(ArrayList<Course> course_List);
	
}

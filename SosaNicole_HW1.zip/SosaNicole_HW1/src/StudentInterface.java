import java.util.ArrayList;

public interface StudentInterface {
	
	// all the tasks a student should be able to do in this course registration system
	
	// max # of students allowed to be registered
	public abstract void viewAllCourses(ArrayList<Course> course_List);
	
	// show all the information about courses that are not full
	public abstract void viewAllNotFullCourses(ArrayList<Course> course_List);
	
	// allows student to register for a course
	public abstract void registerCourse(ArrayList<Course> course_List);
	
	// allows student to leave a course
	public abstract void  withdrawCourse(ArrayList<Course> course_List);
	
	// allows student to view all their registered courses
	public abstract void viewCurrentCourses(ArrayList<Course> course_List);
	
}
